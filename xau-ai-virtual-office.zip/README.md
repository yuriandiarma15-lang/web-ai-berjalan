# XAU AI Virtual Trading Office

Landing page 3D simulasi kantor trading XAU AI. Tidak menjalankan analisis market atau mengirim signal Telegram.

## Jalankan lokal
1. Install Node.js 20+
2. `npm install`
3. `npm run dev`
4. Buka alamat lokal yang ditampilkan Vite.

## Deploy GitHub + Railway
1. Buat repository GitHub baru dan upload seluruh isi folder ini.
2. Railway → New Project → Deploy from GitHub Repo.
3. Pilih repository ini. Railway akan mendeteksi Dockerfile dan membangun website.
4. Setelah deploy sukses, buka Settings → Networking → Generate Domain.

Tidak memerlukan API key atau environment variable untuk versi visual ini.

## Catatan jadwal
Animasi terjadwal berjalan di browser ketika halaman dibuka, menggunakan zona waktu Asia/Jakarta. Jadwal hanya memicu animasi visual; tidak mengirim signal Telegram.
